# Complete Implementation Guide for ERP System
## ASP.NET Core + Next.js + PostgreSQL on Windows Server

---

## 📋 Prerequisites

### Install on Windows Server:
1. **Docker Desktop for Windows** (version 4.0+)
   - Download: https://www.docker.com/products/docker-desktop
   - Enable WSL 2 backend
   - Enable Windows containers support

2. **Git** (optional, for version control)
   - Download: https://git-scm.com/download/win

3. **Curl** (for health checks)
   - Included in Windows 10/Server 2019+
   - Or install: `winget install curl`

---

## 🚀 Initial Setup (First Time)

### Step 1: Prepare Your Project Structure

```
erp-system/
├── backend/                    # Your ASP.NET Core project
│   ├── YourProject.csproj
│   ├── Program.cs
│   ├── Controllers/
│   └── Dockerfile             # Provided
├── frontend/                   # Your Next.js project
│   ├── package.json
│   ├── pages/
│   ├── next.config.js         # Provided
│   └── Dockerfile             # Provided
├── nginx/
│   └── nginx.conf             # Provided
├── backups/                    # Auto-created for DB backups
├── .env                        # Configuration
├── docker-compose.yml          # Provided
└── deploy-update.bat           # Deployment script
```

### Step 2: Configure Environment Variables

Create `.env` file in root directory:

```env
# Database Configuration
DB_NAME=erp_production
DB_USER=erp_admin
DB_PASSWORD=YourSecurePassword123!

# Application Settings
ASPNETCORE_ENV=Production
NODE_ENV=production
API_URL=http://backend:5000

# Ports (change if needed)
POSTGRES_PORT=5432
BACKEND_PORT=5000
FRONTEND_PORT=3000
NGINX_PORT=80
```

### Step 3: Update Dockerfiles

**Backend Dockerfile:** Replace `YourBackendApp.dll` with your actual DLL name
```dockerfile
ENTRYPOINT ["dotnet", "ErpApi.dll"]  # Change this line
```

**Frontend**: Ensure `package.json` has build scripts:
```json
{
  "scripts": {
    "build": "next build",
    "start": "next start"
  }
}
```

### Step 4: Add Health Endpoint to ASP.NET Core

Add this to your `Program.cs`:

```csharp
// Add before app.Run()
app.MapGet("/health", () => Results.Ok(new { status = "healthy", timestamp = DateTime.UtcNow }));
```

---

## 🔧 Deployment Strategies

### Strategy 1: Simple Update (Brief Downtime ~30 seconds)

Use when: Minor updates, low traffic periods

```batch
deploy-update.bat
```

**What it does:**
1. Backs up database
2. Tags current images
3. Builds new images
4. Restarts containers
5. Runs health checks

### Strategy 2: Blue-Green Deployment (Zero Downtime)

Use when: Major updates, high availability needed

```batch
deploy-blue-green.bat
```

**What it does:**
1. Builds new environment on alternate ports
2. Starts new containers
3. Health checks new environment
4. Switches traffic via nginx
5. Removes old containers

---

## 📦 Daily Operations

### Starting the System
```batch
docker-compose up -d
```

### Stopping the System
```batch
docker-compose down
```

### Viewing Logs
```batch
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f backend
docker-compose logs -f frontend
docker-compose logs -f postgres
```

### Health Check
```batch
system-health.bat
```

### Database Backup (Manual)
```batch
docker-compose exec postgres pg_dump -U erp_admin erp_production > backups/manual_backup.sql
```

### Database Restore
```batch
docker-compose exec -T postgres psql -U erp_admin erp_production < backups/backup_file.sql
```

---

## 🔄 Update Workflow (Recommended)

### For Small Changes (Code Updates):
1. Update your code
2. Run: `deploy-update.bat`
3. Verify with: `system-health.bat`

### For Major Changes (Database Schema):
1. Create backup: `backup-database.bat`
2. Test migration locally
3. Run: `deploy-update.bat`
4. If issues: `rollback.bat`

---

## 🛡️ Rollback Procedure

If deployment fails:

```batch
rollback.bat
```

Manual rollback:
```batch
# List available backup tags
docker images | findstr backup

# Rollback to specific version
docker tag erp-backend:backup-20240430_143022 erp-backend:latest
docker tag erp-frontend:backup-20240430_143022 erp-frontend:latest
docker-compose up -d
```

---

## 🔍 Troubleshooting

### Containers won't start
```batch
# Check logs
docker-compose logs

# Check disk space
docker system df

# Clean up old images
docker system prune -a
```

### Database connection issues
```batch
# Verify database is running
docker-compose ps postgres

# Check connection from backend
docker-compose exec backend ping postgres

# Check database logs
docker-compose logs postgres
```

### Performance issues
```batch
# Check resource usage
docker stats

# Restart specific service
docker-compose restart backend
```

---

## 📊 Monitoring

### Automated Health Checks
Create scheduled task in Windows:
1. Open Task Scheduler
2. Create Basic Task
3. Schedule: Every 5 minutes
4. Action: Start program `C:\path\to\system-health.bat`
5. Save output to log file

### Log Rotation
Add to scheduled tasks (weekly):
```batch
docker-compose logs --tail=1000 > logs/archive_%date%.log
docker-compose restart
```

---

## 🔐 Security Recommendations

1. **Change default passwords** in `.env`
2. **Enable HTTPS** in nginx.conf (uncomment SSL section)
3. **Restrict database port**: Remove `5432:5432` from docker-compose.yml
4. **Use secrets management**: Windows Credential Manager or Azure Key Vault
5. **Regular backups**: Schedule daily backups
6. **Update images**: Monthly security updates

---

## 📈 Performance Tuning

### For Backend (ASP.NET Core)
Add to `appsettings.Production.json`:
```json
{
  "Kestrel": {
    "Limits": {
      "MaxConcurrentConnections": 100,
      "MaxRequestBodySize": 104857600
    }
  }
}
```

### For Frontend (Next.js)
In `next.config.js`:
```javascript
{
  output: 'standalone',
  swcMinify: true,
  compress: true
}
```

### For Database (PostgreSQL)
Add to docker-compose.yml under postgres:
```yaml
command: postgres -c max_connections=200 -c shared_buffers=256MB
```

---

## 📞 Quick Reference Commands

| Task | Command |
|------|---------|
| Start system | `docker-compose up -d` |
| Stop system | `docker-compose down` |
| View logs | `docker-compose logs -f [service]` |
| Update system | `deploy-update.bat` |
| Health check | `system-health.bat` |
| Backup DB | `backup-database.bat` |
| Restore DB | `restore-database.bat` |
| Rollback | `rollback.bat` |
| Clean up | `docker system prune -a` |

---

## 🎯 Next Steps

1. ✅ Copy all provided files to your project
2. ✅ Update `.env` with your settings
3. ✅ Modify Dockerfiles with your app names
4. ✅ Add health endpoint to backend
5. ✅ Test locally: `docker-compose up`
6. ✅ Schedule automated backups
7. ✅ Set up monitoring
8. ✅ Document your specific configurations

---

**Need help?** Check logs with `docker-compose logs -f`
