@echo off
REM ================================================================
REM System Health Check and Monitoring Script
REM ================================================================

echo ========================================
echo ERP System Health Check
echo ========================================
echo.

set ERRORS=0

echo [1/6] Checking Docker containers status...
docker ps --filter "name=erp" --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
echo.

echo [2/6] Checking PostgreSQL...
curl -s -o nul -w "PostgreSQL Health: %%{http_code}\n" http://localhost:5432
if %errorlevel% neq 0 (
    echo WARNING: PostgreSQL may not be responding
    set /a ERRORS+=1
)

echo [3/6] Checking Backend API...
curl -s -f http://localhost:5000/health
if %errorlevel% neq 0 (
    echo ERROR: Backend health check failed!
    set /a ERRORS+=1
) else (
    echo Backend: OK
)
echo.

echo [4/6] Checking Frontend...
curl -s -f http://localhost:3000
if %errorlevel% neq 0 (
    echo ERROR: Frontend health check failed!
    set /a ERRORS+=1
) else (
    echo Frontend: OK
)
echo.

echo [5/6] Checking Nginx...
curl -s -f http://localhost/health
if %errorlevel% neq 0 (
    echo ERROR: Nginx health check failed!
    set /a ERRORS+=1
) else (
    echo Nginx: OK
)
echo.

echo [6/6] Checking disk usage...
docker system df
echo.

echo ========================================
if %ERRORS% equ 0 (
    echo All systems operational!
    echo Status: HEALTHY
) else (
    echo Found %ERRORS% issue(s)
    echo Status: UNHEALTHY
    echo.
    echo To view logs:
    echo   docker-compose logs backend
    echo   docker-compose logs frontend
    echo   docker-compose logs postgres
)
echo ========================================
echo.

exit /b %ERRORS%
