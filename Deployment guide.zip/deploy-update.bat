@echo off
REM ================================================================
REM ERP System Zero-Downtime Deployment Script
REM For Windows Server with Docker
REM ================================================================

echo ========================================
echo ERP System Deployment
echo ========================================
echo.

REM Check if Docker is running
docker info >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Docker is not running!
    echo Please start Docker Desktop and try again.
    pause
    exit /b 1
)

REM Set deployment variables
set DEPLOYMENT_DATE=%date:~-4,4%%date:~-7,2%%date:~-10,2%_%time:~0,2%%time:~3,2%%time:~6,2%
set DEPLOYMENT_DATE=%DEPLOYMENT_DATE: =0%
set BACKUP_TAG=backup-%DEPLOYMENT_DATE%

echo [1/8] Creating backup of current containers...
docker-compose exec -T postgres pg_dump -U %DB_USER% %DB_NAME% > backups/db_backup_%DEPLOYMENT_DATE%.sql
if %errorlevel% neq 0 (
    echo WARNING: Database backup failed. Continue anyway? (Y/N)
    set /p continue=
    if /i not "%continue%"=="Y" exit /b 1
)

echo [2/8] Tagging current images as backup...
docker tag erp-backend:latest erp-backend:%BACKUP_TAG%
docker tag erp-frontend:latest erp-frontend:%BACKUP_TAG%

echo [3/8] Pulling latest code from repository...
REM Uncomment if using Git
REM git pull origin main

echo [4/8] Building new images...
docker-compose build --no-cache
if %errorlevel% neq 0 (
    echo ERROR: Build failed!
    pause
    exit /b 1
)

echo [5/8] Running database migrations (if any)...
docker-compose run --rm backend dotnet ef database update
if %errorlevel% neq 0 (
    echo WARNING: Migrations failed. Check manually!
)

echo [6/8] Starting new containers...
docker-compose up -d
if %errorlevel% neq 0 (
    echo ERROR: Failed to start containers!
    echo Attempting rollback...
    call rollback.bat
    pause
    exit /b 1
)

echo [7/8] Waiting for services to be healthy...
timeout /t 30 /nobreak >nul

echo [8/8] Running health checks...
call health-check.bat
if %errorlevel% neq 0 (
    echo WARNING: Health checks failed!
    echo Deployment completed but services may not be fully healthy.
    echo Check logs with: docker-compose logs
)

echo.
echo ========================================
echo Deployment completed successfully!
echo ========================================
echo Backup tag: %BACKUP_TAG%
echo.
echo To rollback: rollback.bat
echo To view logs: docker-compose logs -f
echo.
pause
