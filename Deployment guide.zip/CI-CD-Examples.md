# CI/CD Pipeline Configuration
# Choose one: GitHub Actions OR Azure DevOps

# ============================================================
# OPTION 1: GitHub Actions
# ============================================================
# File: .github/workflows/deploy.yml

name: Deploy ERP System

on:
  push:
    branches: [ main ]
  workflow_dispatch:

jobs:
  deploy:
    runs-on: windows-latest
    
    steps:
    - name: Checkout code
      uses: actions/checkout@v3
    
    - name: Setup .NET
      uses: actions/setup-dotnet@v3
      with:
        dotnet-version: '8.0.x'
    
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '20'
    
    - name: Run tests
      run: |
        cd backend
        dotnet test
    
    - name: Build and Push to Server
      env:
        SERVER_HOST: ${{ secrets.SERVER_HOST }}
        SERVER_USER: ${{ secrets.SERVER_USER }}
        SERVER_PASSWORD: ${{ secrets.SERVER_PASSWORD }}
      run: |
        # Create deployment package
        Compress-Archive -Path * -DestinationPath deploy.zip
        
        # Copy to server (use SCP or similar)
        # pscp deploy.zip user@server:/path/
        
        # SSH and deploy
        # plink user@server "cd /path && deploy-update.bat"

# ============================================================
# OPTION 2: Azure DevOps Pipeline
# ============================================================
# File: azure-pipelines.yml

trigger:
  branches:
    include:
    - main

pool:
  vmImage: 'windows-latest'

variables:
  buildConfiguration: 'Release'

stages:
- stage: Build
  jobs:
  - job: BuildAndTest
    steps:
    - task: UseDotNet@2
      inputs:
        version: '8.0.x'
    
    - task: NodeTool@0
      inputs:
        versionSpec: '20.x'
    
    - task: DotNetCoreCLI@2
      displayName: 'Restore Backend'
      inputs:
        command: 'restore'
        projects: 'backend/**/*.csproj'
    
    - task: DotNetCoreCLI@2
      displayName: 'Build Backend'
      inputs:
        command: 'build'
        projects: 'backend/**/*.csproj'
        arguments: '--configuration $(buildConfiguration)'
    
    - task: DotNetCoreCLI@2
      displayName: 'Run Tests'
      inputs:
        command: 'test'
        projects: 'backend/**/*Tests.csproj'
    
    - task: Npm@1
      displayName: 'Install Frontend Dependencies'
      inputs:
        command: 'ci'
        workingDir: 'frontend'
    
    - task: Npm@1
      displayName: 'Build Frontend'
      inputs:
        command: 'custom'
        customCommand: 'run build'
        workingDir: 'frontend'
    
    - task: PublishBuildArtifacts@1
      inputs:
        pathToPublish: '$(Build.ArtifactStagingDirectory)'
        artifactName: 'drop'

- stage: Deploy
  dependsOn: Build
  condition: succeeded()
  jobs:
  - deployment: DeployToProduction
    environment: 'Production'
    strategy:
      runOnce:
        deploy:
          steps:
          - task: DownloadBuildArtifacts@1
            inputs:
              artifactName: 'drop'
          
          - task: PowerShell@2
            displayName: 'Deploy to Server'
            inputs:
              targetType: 'inline'
              script: |
                # Copy files to server
                Copy-Item -Path "$(Pipeline.Workspace)/drop/*" -Destination "\\server\share\erp\" -Recurse -Force
                
                # Execute deployment script on server
                Invoke-Command -ComputerName $(serverName) -ScriptBlock {
                  cd C:\ERP-System
                  .\deploy-update.bat
                }

# ============================================================
# OPTION 3: Jenkins Pipeline
# ============================================================
# File: Jenkinsfile

pipeline {
    agent any
    
    environment {
        DOTNET_VERSION = '8.0'
        NODE_VERSION = '20'
    }
    
    stages {
        stage('Checkout') {
            steps {
                checkout scm
            }
        }
        
        stage('Build Backend') {
            steps {
                bat '''
                    cd backend
                    dotnet restore
                    dotnet build --configuration Release
                '''
            }
        }
        
        stage('Test') {
            steps {
                bat '''
                    cd backend
                    dotnet test
                '''
            }
        }
        
        stage('Build Frontend') {
            steps {
                bat '''
                    cd frontend
                    npm ci
                    npm run build
                '''
            }
        }
        
        stage('Deploy') {
            when {
                branch 'main'
            }
            steps {
                bat '''
                    REM Copy files to deployment server
                    xcopy /E /Y * \\\\server\\erp-deploy\\
                    
                    REM Execute deployment script remotely
                    psexec \\\\server -u admin -p password cmd /c "cd C:\\ERP-System && deploy-update.bat"
                '''
            }
        }
        
        stage('Health Check') {
            steps {
                bat '''
                    timeout /t 60 /nobreak
                    psexec \\\\server -u admin -p password cmd /c "cd C:\\ERP-System && system-health.bat"
                '''
            }
        }
    }
    
    post {
        success {
            emailext (
                subject: "✅ ERP Deployment Successful - Build #${BUILD_NUMBER}",
                body: "Deployment completed successfully.",
                to: "team@company.com"
            )
        }
        failure {
            emailext (
                subject: "❌ ERP Deployment Failed - Build #${BUILD_NUMBER}",
                body: "Deployment failed. Check Jenkins logs.",
                to: "team@company.com"
            )
        }
    }
}

# ============================================================
# Manual PowerShell Deployment Script (No CI/CD)
# ============================================================
# File: deploy-from-git.ps1

param(
    [string]$ServerPath = "C:\ERP-System",
    [string]$GitRepo = "https://github.com/your-org/erp-system.git",
    [string]$Branch = "main"
)

Write-Host "Starting deployment from Git..." -ForegroundColor Green

# Navigate to server path
Set-Location $ServerPath

# Pull latest changes
Write-Host "Pulling latest code from $Branch..." -ForegroundColor Yellow
git fetch origin
git checkout $Branch
git pull origin $Branch

if ($LASTEXITCODE -ne 0) {
    Write-Host "Git pull failed!" -ForegroundColor Red
    exit 1
}

# Run deployment
Write-Host "Running deployment script..." -ForegroundColor Yellow
.\deploy-update.bat

if ($LASTEXITCODE -ne 0) {
    Write-Host "Deployment failed!" -ForegroundColor Red
    exit 1
}

Write-Host "Deployment completed successfully!" -ForegroundColor Green
