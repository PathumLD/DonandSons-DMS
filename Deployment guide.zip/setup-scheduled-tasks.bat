@echo off
REM ================================================================
REM Setup Automated Tasks in Windows Task Scheduler
REM Run this script as Administrator
REM ================================================================

echo ========================================
echo Setting Up Automated Tasks
echo ========================================
echo.

REM Get current directory
set SCRIPT_DIR=%~dp0

echo Creating scheduled tasks...
echo.

REM Task 1: Daily Database Backup at 2 AM
echo [1/3] Setting up daily backup (2:00 AM)...
schtasks /Create /TN "ERP_Daily_Backup" /TR "%SCRIPT_DIR%automated-backup.bat" /SC DAILY /ST 02:00 /RU SYSTEM /F
if %errorlevel% equ 0 (
    echo ✓ Daily backup task created
) else (
    echo ✗ Failed to create daily backup task
)

REM Task 2: Health Check every 15 minutes
echo [2/3] Setting up health monitoring (every 15 minutes)...
schtasks /Create /TN "ERP_Health_Check" /TR "%SCRIPT_DIR%system-health.bat >> %SCRIPT_DIR%logs\health_check.log" /SC MINUTE /MO 15 /RU SYSTEM /F
if %errorlevel% equ 0 (
    echo ✓ Health check task created
) else (
    echo ✗ Failed to create health check task
)

REM Task 3: Weekly cleanup on Sunday at 3 AM
echo [3/3] Setting up weekly cleanup (Sunday 3:00 AM)...
schtasks /Create /TN "ERP_Weekly_Cleanup" /TR "docker system prune -f" /SC WEEKLY /D SUN /ST 03:00 /RU SYSTEM /F
if %errorlevel% equ 0 (
    echo ✓ Weekly cleanup task created
) else (
    echo ✗ Failed to create weekly cleanup task
)

echo.
echo ========================================
echo Task Setup Complete!
echo ========================================
echo.
echo Created tasks:
schtasks /Query /TN "ERP_*" /FO LIST
echo.
echo To view in Task Scheduler: taskschd.msc
echo To disable a task: schtasks /Change /TN "task_name" /DISABLE
echo To delete a task: schtasks /Delete /TN "task_name"
echo.
pause
