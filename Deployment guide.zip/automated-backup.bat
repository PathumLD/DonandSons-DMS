@echo off
REM ================================================================
REM Automated Database Backup Script with Retention
REM ================================================================

echo ========================================
echo Database Backup Script
echo ========================================
echo.

REM Create backup directory if not exists
if not exist "backups" mkdir backups

REM Generate timestamp
set BACKUP_DATE=%date:~-4,4%%date:~-7,2%%date:~-10,2%_%time:~0,2%%time:~3,2%%time:~6,2%
set BACKUP_DATE=%BACKUP_DATE: =0%
set BACKUP_FILE=backups/db_backup_%BACKUP_DATE%.sql

echo [1/4] Creating database backup...
docker-compose exec -T postgres pg_dump -U %DB_USER% %DB_NAME% > %BACKUP_FILE%

if %errorlevel% neq 0 (
    echo ERROR: Backup failed!
    exit /b 1
)

echo [2/4] Compressing backup...
powershell Compress-Archive -Path %BACKUP_FILE% -DestinationPath %BACKUP_FILE%.zip -Force
del %BACKUP_FILE%

echo [3/4] Verifying backup...
if exist "%BACKUP_FILE%.zip" (
    echo Backup created successfully: %BACKUP_FILE%.zip
    for %%A in ("%BACKUP_FILE%.zip") do echo Size: %%~zA bytes
) else (
    echo ERROR: Backup file not found!
    exit /b 1
)

echo [4/4] Cleaning old backups (keeping last 30 days)...
forfiles /P backups /M db_backup_*.zip /D -30 /C "cmd /c del @path" 2>nul

echo.
echo ========================================
echo Backup completed successfully!
echo ========================================
echo Location: %BACKUP_FILE%.zip
echo.

REM Optional: Copy to network drive
REM if exist "\\server\backups\" (
REM     echo Copying to network backup location...
REM     copy "%BACKUP_FILE%.zip" "\\server\backups\" /Y
REM )

exit /b 0
